# Jenkins Pipeline Examples

This repository contains example declarative pipelines and shared libraries (found in the **vars** directory) for Jenkins (http://jenkins.io).


### Jenkins-ReadPom

This example pipeline reads the pom.xml file in the project's root directory and outputs the project's version number using echo.

**Note**: This pipeline example requires that the **Pipeline Utility Steps** plugin be installed in order to run.
