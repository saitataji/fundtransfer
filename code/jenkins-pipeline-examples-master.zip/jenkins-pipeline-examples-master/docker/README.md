# Jenkins Pipeline Examples - Docker

The examples in this folder demonstrate how to use Docker images as build agents in pipelines and how to build Docker images within pipelines.
