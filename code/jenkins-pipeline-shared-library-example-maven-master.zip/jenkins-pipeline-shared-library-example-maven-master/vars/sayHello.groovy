// vars/sayHello.groovy

def call(String name = "human") {
    echo "Hello, ${name}."
}