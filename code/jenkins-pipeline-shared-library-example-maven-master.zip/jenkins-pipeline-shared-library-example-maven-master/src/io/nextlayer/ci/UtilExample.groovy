#!/usr/bin/env groovy
package io.nextlayer.ci

class UtilExample {

    String doSomething() {
        return "Something done"
    }
}
